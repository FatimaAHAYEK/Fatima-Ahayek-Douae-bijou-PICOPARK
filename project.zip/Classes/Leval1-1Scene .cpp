#include "Leval1Scene.h"

USING_NS_CC;

Scene* Leval1Scene::createScene()
{
    return Leval1Scene::create();
}
//variable pou bg
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}


bool Leval1Scene::init()
{
   
    if ( !Scene::init() )
    {
        return false;
    }

    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    /*
 
    auto menu = Menu::create(closeItem,  NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);
    */
    auto sprite = Sprite::create("img/pico2.png");
    if (sprite == nullptr)
    {
        problemLoading("'img/pico2.png'");
    }
    else
    {
        // position the sprite on the center of the screen
        sprite->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height / 2 + origin.y));

        // add the sprite as a child to this layer
        this->addChild(sprite, 0);
    }
   
    return true;
}


void Leval1Scene::menuCloseCallback(Ref* pSender)
{
    //Close the cocos2d-x game scene and quit the application
    Director::getInstance()->end();



}
