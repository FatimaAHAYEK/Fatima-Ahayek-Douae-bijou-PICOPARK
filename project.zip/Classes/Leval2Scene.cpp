#include "Leval1Scene.h"

USING_NS_CC;

Scene* Leval1Scene::createScene()
{
    return Leval1Scene::create();
}

// Print useful error message instead of segfaulting when files are not there.
static void problemLoading(const char* filename)
{
    printf("Error while loading: %s\n", filename);
    printf("Depending on how you compiled you might have to add 'Resources/' in front of filenames in HelloWorldScene.cpp\n");
}

// on "init" you need to initialize your instance
bool Leval1Scene::init()
{
    if (!Scene::init())
    {
        return false;
    }
   // auto map = Director::getInstance()->getVisibleSize();
    auto visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    auto fst = Director::getInstance()->getWinSize();


    auto bg = Sprite::create("img/back.png");
     bg->setPosition(Vec2(visibleSize * 0.5f) + origin);

     bg->setPosition(Vec2(visibleSize.width / 2 + origin.x, visibleSize.height + origin.y));
     bg->setScale(visibleSize.width / bg->getContentSize().width);
     bg->getTexture()->setAliasTexParameters();
     addChild(bg);


    auto bg2 = Sprite::create("img/game.png");
      bg2->setAnchorPoint(Vec2::ZERO);
      bg2->setPosition(fst.width - 450, fst.height * 0.25);
      bg2->setScale(0.1, 0.1);
      addChild(bg2,1);

     auto bg3= Sprite::create("img/nj.png");
     //  bg2->setAnchorPoint(Vec2::ZERO);
     bg3->setPosition(fst.width - 100, fst.height * 0.400);
     bg3->setScale(0.2, 0.3);
     addChild(bg3,1);
     
     auto bg4= Sprite::create("img/nj.png");
     //  bg2->setAnchorPoint(Vec2::ZERO);
     bg4->setPosition(fst.width -200, fst.height * 0.400);
     bg4->setScale(0.2, 0.3);
     addChild(bg4, 1);

     auto bg5 = Sprite::create("img/nj.png");
     //  bg2->setAnchorPoint(Vec2::ZERO);
     bg5->setPosition(fst.width -300, fst.height * 0.400);
     bg5->setScale(0.2, 0.3);
     addChild(bg5, 1);


     auto keyboardListener = EventListenerKeyboard::create();
     keyboardListener->onKeyPressed = [](EventKeyboard::KeyCode keyCode, Event* event) {

         auto bg2 = static_cast<Sprite*>(event->getCurrentTarget());
         Vec2 loc = event->getCurrentTarget()->getPosition();


         switch (keyCode)
         {
         case EventKeyboard::KeyCode::KEY_LEFT_ARROW:
             static int nx;
             event->getCurrentTarget()->setPosition(loc.x -= 10, loc.y);
             nx -= 10;

             break;
         case EventKeyboard::KeyCode::KEY_RIGHT_ARROW:
             event->getCurrentTarget()->setPosition(loc.x += 10, loc.y);
             nx += 10;
             break;
         case EventKeyboard::KeyCode::KEY_UP_ARROW:
            

             bg2->runAction(Sequence::create(JumpBy::create(3.0, Point(0, loc.y), 10, 1), JumpTo::create(3.0, Point(loc.x + nx, loc.y), 10, 1), nullptr));

             break;
         case EventKeyboard::KeyCode::KEY_DOWN_ARROW:
             bg2->runAction(JumpTo::create(3.0, Point(loc.x + nx + 15, loc.y), 10, 1));
             break;
         case EventKeyboard::KeyCode::KEY_V:
             event->getCurrentTarget()->setPosition(0, 0);
             break;
         }};

       this->getEventDispatcher()->addEventListenerWithSceneGraphPriority(keyboardListener , bg2);
   
       

       auto iteamLayer = bg2->getLayer("game")

       auto tileSize = bg2->getTileSize();

       int tileX = (int)(pos.x - bg2->getPosition().x / tileSize.width);


       int tileY = (int)(bg2->getContentSize().height - pos.y + bg2->getPosition().y / tileSize.height );

       if ((0 <= tileX && bg2->getMapSize().width) && (0 <= tileY && tileY < bg2->getMapSize().height))
       {
           auto gid2 = iteamLayer->getTileGiDAt(Vec2(tileX, tileY));
           auto gid = obsLayer->getTileGIDAT(Vec2(tileX, tileY));
       }
      

       if (gid2 == 2)
       {
           log("bg4");



       }
       





  /*   auto keyboardListener = EventListenerKeyboard::create();

       keyboardListener->onKeyPressed = CC_CALLBACK_2(SCENE1::onKeyPressed, this);
       keyboardListener->onKeyReleased = CC_CALLBACK_2(SCENE1::onKeyPressed, this);

       Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(keyboardListener, this);

       keyboardListener->onKeyPressed = [player](EventKeyboard::KeyCode KeyCode, Event* event)
       {

           if (KeyCode == EventKeyboard::KeyCode::KEY_UP_ARROW) {
               auto action1 = JumpBy::create(0.57f, Vec2(50, 100), 15.0f, 1);
               auto easeAction = EaseOut::create(action1, 2.0f);
               player->runAction(action1);
               cocos2d::AudioEngine::preload("jump.mp3"); //upload de notre music mp3 en v4 de cocos
               cocos2d::AudioEngine::play2d("jump.mp3");

           }
           if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
               auto jump = JumpBy::create(0.5f, Vec2(50, 50), 20.0f, 1);
               MoveBy* moveAction = MoveBy::create(1.2, Vec2(70, 0));
               RepeatForever* repeatAction = RepeatForever::create(moveAction);
               player->runAction(repeatAction);

           }
           if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
               auto jump = JumpBy::create(0.5f, Vec2(50, 50), 50.0f, 1);
               MoveBy* moveAction = MoveBy::create(1.2, Vec2(-70, 0));
               RepeatForever* repeatAction = RepeatForever::create(moveAction);
               player->runAction(repeatAction);

           }

       };


       keyboardListener->onKeyReleased = [player](EventKeyboard::KeyCode KeyCode, Event* event)
       {
           if (KeyCode == EventKeyboard::KeyCode::KEY_RIGHT_ARROW) {
               player->stopAllActions();
           }
           if (KeyCode == EventKeyboard::KeyCode::KEY_LEFT_ARROW) {
               player->stopAllActions();
           }

       };*/  

 return true;

 

}






void Leval1Scene::onKeyPressed(Ref* pSender)
{
    //Close the cocos2d-x game scene and quit the application
    Director::getInstance()->end();



}
