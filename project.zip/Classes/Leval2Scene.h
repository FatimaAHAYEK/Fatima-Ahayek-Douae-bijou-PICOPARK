
#ifndef __Leval1_SCENE_H__
#define __Leval1_SCENE_H__

#include "cocos2d.h"

class Leval1Scene : public cocos2d::Scene
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    
    // a selector callback
    void menuCloseCallback(cocos2d::Ref* pSender);
    void onKeyPressed(cocos2d::Ref* pSender);
  
    CREATE_FUNC(Leval1Scene);
};

#endif // __HELLOWORLD_SCENE_H__
